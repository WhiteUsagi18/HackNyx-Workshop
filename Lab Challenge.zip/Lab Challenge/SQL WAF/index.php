<?php
$DB_HOST = 'db';
$DB_USER = 'root';
$DB_PASS = 'wafpassword';
$DB_NAME = 'sqlwafDB';

$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

function is_malicious($input) {
    $blacklist = ['select', 'union', 'insert', 'update', 'delete', 'drop', 'from', 'SELECT', 'UNION', 'INSERT', 'UPDATE', 'DELETE', 'DROP', 'FROM', 'or', 'and', 'OR', 'AND'];
    
    foreach ($blacklist as $bad_word) {
        if (strpos($input, $bad_word) !== false) {
            return $bad_word; 
        }
    }
    return false;
}

$results = "";
$error_msg = "";

if(isset($_POST['user_id'])){
    $user_input = $_POST['user_id'];
    $blocked_word = is_malicious($user_input);

    if ($blocked_word) {
        $error_msg = "WAF BLOCK: The exact string '$blocked_word' was found in your input!";
    } else {
        $query = "SELECT user_id, user_name, user_role FROM user WHERE user_id = '$user_input';";
        
        if ($result = $mysqli->query($query)) {
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $results .= "<div class='user-card'>
                                    <strong>ID:</strong> {$row['user_id']}<br>
                                    <strong>User:</strong> {$row['user_name']}<br>
                                    <strong>Role:</strong> {$row['user_role']}
                                 </div>";
                }
            } else {
                $results = "<p style='color: #ffd700; text-align: center; margin-top: 20px;'>User ID not found.</p>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manual Blacklist Lab</title>
    <style>
        body { background: #121212; color: #e0e0e0; font-family: sans-serif; display: flex; justify-content: center; padding-top: 50px; }
        .container { width: 500px; background: #1e1e1e; padding: 20px; border-radius: 10px; border: 1px solid #333; }
        .error { color: #ff4444; background: #2a1010; padding: 10px; border: 1px solid #ff4444; margin-bottom: 10px; }
        input[type="text"] { width: 100%; padding: 10px; margin: 10px 0; background: #2c2c2c; border: 1px solid #444; color: #fff; box-sizing: border-box; }
        input[type="submit"] { width: 100%; padding: 10px; background: #00e676; border: none; font-weight: bold; cursor: pointer; }
        .user-card { background: #252525; padding: 10px; margin-top: 10px; border-left: 4px solid #00e676; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Personnel Lookup</h2>
        <?php if ($error_msg): ?>
            <div class="error"><?php echo $error_msg; ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="text" name="user_id" placeholder="Enter ID..." required>
            <input type="submit" value="Search">
        </form>
        <div id="results"><?php echo $results; ?></div>
    </div>
</body>
</html>