CREATE DATABASE IF NOT EXISTS sqlwafDB;
USE sqlwafDB;

CREATE TABLE user (
    user_id INT PRIMARY KEY,
    user_name VARCHAR(50),
    user_role VARCHAR(50)
);

INSERT INTO user (user_id, user_name, user_role) VALUES (1, 'admin', 'SuperAdmin'), (2, 'guest', 'General Staff');

CREATE TABLE secret_flag (
    id INT PRIMARY KEY,
    flag_content VARCHAR(100)
);

INSERT INTO secret_flag (id, flag_content) 
VALUES (1, CONCAT('HNYX{', LOWER(HEX(RANDOM_BYTES(16))), '}'));