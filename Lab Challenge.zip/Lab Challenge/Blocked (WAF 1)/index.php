<?php
$is_blocked = false;
$log_message = "WAITING FOR INPUT";
$flag = getenv('FLAG');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = $_POST['input'] ?? '';

    // for this lab simulation, all strings are malicious except 'HNYX'
    if (!preg_match('/^HNYX$/', $input)) {
        $is_blocked = true;
        $log_message = "ALARM: MALICIOUS INPUT. THE INPUT HAS BEEN BLOCKED.";
    }
    
    else if ($input === '') {
        $log_message = "WARNING: EMPTY INPUT SUBMITTED.";
    }
    
    else {
        $log_message = "SUCCESS: AUTHORIZED INPUT RECEIVED.";
        $success_output = "SUCCESSFUL " . $flag;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>WAF LOG</title>
    <style>
        body { background: #0a0a0a; color: #00ff41; font-family: 'Courier New', Courier, monospace; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .waf-panel { border: 2px solid #00ff41; padding: 20px; width: 600px; background: #000; box-shadow: 0 0 15px #00ff41; }
        .header { border-bottom: 2px solid #00ff41; padding-bottom: 10px; margin-bottom: 20px; text-align: center; }
        .log-screen { background: #051405; border: 1px solid #004400; padding: 15px; margin-bottom: 20px; font-size: 0.9em; height: 100px; overflow: hidden; }
        .blocked { color: #ff0000; text-shadow: 0 0 5px #ff0000; }
        .input-area { text-align: center; }
        input[type="text"] { background: #000; border: 1px solid #00ff41; color: #00ff41; padding: 10px; width: 80%; margin-bottom: 15px; outline: none; }
        input[type="submit"] { background: #00ff41; color: #000; border: none; padding: 10px 25px; font-weight: bold; cursor: pointer; }
        input[type="submit"]:hover { background: #00cc33; }
    </style>
</head>
<body>
    <div class="waf-panel">
        <div class="header">
            <h1>WAF LOG</h1>
            <p></p>
            <p>Status: <span style="color: <?php echo $is_blocked ? '#ff0000' : '#00ff41'; ?>">PROTECTED</span></p>
        </div>

        <div class="log-screen">
            [<?php echo date('H:i:s'); ?>] IP: 127.0.0.1<br>
            [LOG]: <?php echo $log_message; ?><br>
            <?php if (isset($success_output)): ?>
                <br>[CORE]: <span style="color: white;"><?php echo $success_output; ?></span>
            <?php endif; ?>
        </div>

        <form class="input-area" method="POST">
            <input type="text" name="input" placeholder="Enter Authorization Character..." autocomplete="off">
            <br>
            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>