<?php
$message = "Welcome to the Burp Challenge";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['input'])) {
        $message = "Input received but no flag for you. Try reading the source code.";
    }
    
    else {
        $flag = getenv('FLAG');
        $message = "Congratulations, you passed the Burp challenge! <br>" . $flag;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>The Burp Challenge</title>
    <style>
        body { font-family: sans-serif; display: flex; justify-content: center; margin-top: 50px; background: #f4f4f4; }
        .container { border: 1px solid #ccc; padding: 20px; border-radius: 8px; background: white; box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 400px; text-align: center; }
        input[type="text"] { width: 80%; padding: 10px; margin-bottom: 10px; }
        input[type="submit"] { padding: 10px 20px; cursor: pointer; background: #007bff; color: white; border: none; border-radius: 4px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Enter the secret code:</h2>
        <p><strong><?php echo $message; ?></strong></p>
        <form method="POST">
            <input type="text" name="input" placeholder="Type something...">
            <br>
            <input type="submit" value="Submit">
        </form>
    </div>
</body>
</html>