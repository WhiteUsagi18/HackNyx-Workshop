Challenge Name: 403
Challenge Difficulty: Medium\

Description:
Whoever created this website thinks that the 403 page is enough to stop a GOAT hacker like me

flag: K0CTF{@dM1N_m@sT3r_bYp@Ss1Ng_403}